import numpy as np
import gridworld as Gridworld

class ValueIteration:
    
    def __init__(self, seed=None):
        # The following are recommended hyper-parameters.
        
        # Initial learning rate: 0.1
        # Learning rate decay for each episode: 0.998
        # Minimum learning rate: 0.001
        # Initial epsilon for exploration: 0.5
        # Epsilon decay for each episode: 0.99
        
        self.q_table = np.zeros((64, 4))  # The Q table.
        self.learning_rate = 0.1  # Learning rate. 
        self.learning_rate_decay = 0.998  # You may decay the learning rate as the training proceeds.
        self.min_learning_rate = 0.001
        self.epsilon = 0.5  # For the epsilon-greedy exploration. 
        self.epsilon_decay = 0.99  # You may decay the epsilon as the training proceeds.
        if seed is None:
            self.rng = np.random.default_rng()
        else:
            self.rng = np.random.default_rng(seed)
            
    def value_iteration():
    """
    Please use value iteration to compute the optimal value function and store it into the vector V with size 64
    For example, V[0] means the optimal value function for state 0.
    """
    V = np.zeros((64,))
    temp = np.zeros((64,))
    converged = False
    iter = 0
    while not converged:
        temp = V
        for i in range(len(V)):
            current_state = i
            Q = np.zeros((4,))
            for current_action in range(4):
                next_state = env.state_transition_func(current_state, current_action)
                if next_state == 6:
                    reward = 10.0
                    Q[current_action] = reward + 0.9 * temp[next_state]
                else:
                    reward = -1.5
                    Q[current_action] = reward + 0.9 * temp[next_state]
            V[current_state] = np.max(Q)
            if current_state == 6:
                V[current_state] = 0
        if iter == 1000:
            converged = True
            print('Max iteration reached')
        iter += 1
    assert NotImplementedError()
    return V